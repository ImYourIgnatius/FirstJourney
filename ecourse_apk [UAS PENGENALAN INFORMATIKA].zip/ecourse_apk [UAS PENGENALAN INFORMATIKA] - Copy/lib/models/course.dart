class Course {
  String name;
  double completedPercentage;
  String author;
  String thumbnail;

  Course({
    required this.author,
    required this.completedPercentage,
    required this.name,
    required this.thumbnail,
  });
}

List<Course> courses = [
  Course(
    author: "Hilman Maulana",
    completedPercentage: .75,
    name: "Dasar-Dasar Flutter Pemula",
    thumbnail: "assets/icons/flutter.jpg",
  ),
  Course(
    author: "Helmy Noorhakim",
    completedPercentage: .60,
    name: "Dasar-Dasar React Pemula",
    thumbnail: "assets/icons/react.jpg",
  ),
  Course(
    author: "Muhammad Satrio",
    completedPercentage: .75,
    name: "Javascript -  Full Pembelajaran Final",
    thumbnail: "assets/icons/node.png",
  ),
  Course(
    author: "Faraby",
    completedPercentage: .75,
    name: "Flutter - Pembelajaran StatefullWidget",
    thumbnail: "assets/icons/flutter.jpg",
  ),
  Course(
    author: "Hilman Maulana",
    completedPercentage: .60,
    name: "Komponen Utama React - Basic",
    thumbnail: "assets/icons/react.jpg",
  ),
  Course(
    author: "Reza Arap",
    completedPercentage: .75,
    name: "Node - Full Pembelajaran Final",
    thumbnail: "assets/icons/node.png",
  ),
];
