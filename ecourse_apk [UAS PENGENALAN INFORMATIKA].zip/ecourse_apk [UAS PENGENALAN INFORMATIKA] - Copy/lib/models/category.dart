class Category {
  String thumbnail;
  String name;
  int noOfCourses;

  Category({
    required this.name,
    required this.noOfCourses,
    required this.thumbnail,
  });
}

List<Category> categoryList = [
  Category(
    name: 'Java',
    noOfCourses: 55,
    thumbnail: 'assets/icons/java.png',
  ),
  Category(
    name: 'Python',
    noOfCourses: 20,
    thumbnail: 'assets/icons/python.png',
  ),
  Category(
    name: 'Aplikasi Mobile',
    noOfCourses: 16,
    thumbnail: 'assets/icons/aplikasi_mobile.png',
  ),
  Category(
    name: 'UI/UX',
    noOfCourses: 25,
    thumbnail: 'assets/icons/uiux.png',
  ),
];
