package com.example.ecourse_apk

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
